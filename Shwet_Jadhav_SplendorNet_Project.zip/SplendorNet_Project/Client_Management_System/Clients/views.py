from django.shortcuts import render,redirect
from.forms import EmployeeForm, Employee


# Create your views here.
def add_emp_view(request):
    form = EmployeeForm()
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('show_url')
    template_name = 'curdapp/add_emp.html'
    context = {'form': form}
    return render(request, template_name, context)


def show_view(request):
    obj = Employee.objects.all()
    template_name = 'curdapp/show.html'
    context ={'data': obj}
    return render(request, template_name, context)


def update_view(request,pk):
    obj = Employee.objects.get(id=pk)
    form = EmployeeForm(instance=obj)
    if request.method == 'POST':
        form = EmployeeForm(request.POST, instance=obj)
        if form.is_valid():
            form.save()
            return redirect('show_url')
    template_name = 'curdapp/add_emp.html'
    context ={'form': form}
    return render(request, template_name, context)


def delete_view(request, pk):
    obj = Employee.objects.get(id=pk)
    if request.method == 'POST':
        obj.delete()
        return redirect('show_url')
    template_name = 'curdapp/del_confirm.html'
    context ={'data': obj}
    return render(request, template_name, context)
