from django import forms
from .models import Employee


class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = '__all__'
        labels = {

            'id' : 'Client ID',
            'name': 'Client Name',
            'company': 'Client Company',
            'email_id': 'Email Id',
            'department':'Department',
            'dateOfJoining': 'Date of Joining',
            'status' : 'Status',
            'projectDomain':'Project Domain',

        }
        widgets = {
            'dateOfJoining': forms.DateInput(attrs={'type': 'YYYY-MM-DD'}),
        }